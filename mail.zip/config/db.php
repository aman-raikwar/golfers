<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=golfer',
    //'username' => 'golferuser',
    //'password' => '4Twz8~36ple0',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8',
];
