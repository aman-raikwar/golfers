<?php
/* @var $this yii\web\View */
/* @var $form yii\bootstrap\ActiveForm */
/* @var $model app\models\LoginForm */


use yii\helpers\Html;
use yii\bootstrap\Nav;
use yii\bootstrap\NavBar;
use yii\widgets\Breadcrumbs;
use app\assets\AppAsset;
use yii\helpers\Url; 

//$this->title = 'Login';
//$this->params['breadcrumbs'][] = $this->title;
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
<head>
    <meta charset="<?= Yii::$app->charset ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="<?php Yii::$app->getHomeUrl(); ?>/favicon.ico" type="image/x-icon">
    <?= Html::csrfMetaTags() ?>
    <title><?= Html::encode($this->title) ?></title>

<!-- App favicon -->
<link rel="shortcut icon" href="images/favicon.ico">

<!-- App css -->
<link href="<?php echo Yii::$app->request->baseUrl; ?>/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo Yii::$app->request->baseUrl; ?>/css/icons.css" rel="stylesheet" type="text/css" />
<link href="<?php echo Yii::$app->request->baseUrl; ?>/css/style.css" rel="stylesheet" type="text/css" />

<script src="<?php echo Yii::$app->request->baseUrl; ?>/js/modernizr.min.js"></script>
</head>
<body>

<?php $this->beginBody() ?>
    
     <?= $content ?>

    
    <script>
            var resizefunc = [];
        </script>

        <!-- jQuery  -->
        <script src="<?php echo Yii::$app->request->baseUrl; ?>/js/jquery.min.js"></script>
        <script src="<?php echo Yii::$app->request->baseUrl; ?>/js/tether.min.js"></script><!-- Tether for Bootstrap -->
        <script src="<?php echo Yii::$app->request->baseUrl; ?>/js/bootstrap.min.js"></script>
        <script src="<?php echo Yii::$app->request->baseUrl; ?>/js/metisMenu.min.js"></script>
        <script src="<?php echo Yii::$app->request->baseUrl; ?>/js/waves.js"></script>
        <script src="<?php echo Yii::$app->request->baseUrl; ?>/js/jquery.slimscroll.js"></script>

        <!-- App js -->
        <script src="<?php echo Yii::$app->request->baseUrl; ?>/js/jquery.core.js"></script>
        <script src="<?php echo Yii::$app->request->baseUrl; ?>/js/jquery.app.js"></script>

<?php $this->endBody() ?>
</body>
</html>
<?php $this->endPage() ?>