<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\PlayerSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */
?>

<div class="content-page">

    <!-- content -->
    <div class="content">

        <!-- container -->
        <div class="container-fluid">
            <!-- Player Activity Table Row -->
            <div class="row top-row">
                <div class="col-12">
                    <div class="portlet">
                        <div class="portlet-heading bg-inverse">
                            <h3 class="portlet-title">
                                Golfers
                            </h3>
                            <div class="portlet-widgets">
                                <a href="#" data-toggle="modal" data-target="#addGolfer"><i class="mdi mdi-plus">Add a Golfer</i></a>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                        <!-- Add Golfer Modal -->
                        <div id="addGolfer" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><i class="fi-cross"></i></button>
                                        <h4 class="modal-title" id="myModalLabel">Add a Golfer</h4>
                                    </div>
                                    <div class="modal-body">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label for="field-1" class="control-label">Golfer Card Number</label>
                                                    <select class="select2 form-control select2" multiple="multiple" placeholder="Choose ..." id="field-1">

                                                        <option value="110001">110001</option>
                                                        <option value="220001">220001</option>
                                                        <option value="110001">330001</option>
                                                        <option value="110001">335101</option>
                                                        <option value="110001">335201</option>
                                                        <option value="110001">336001</option>
                                                        <option value="110001">337001</option>
                                                        <option value="110001">338001</option>
                                                        <option value="220001">440001</option>
                                                        <option value="220001">550001</option>
                                                        <option value="110001">660001</option>
                                                        <option value="220001">770001</option>
                                                        <option value="110001">880001</option>
                                                        <option value="220001">990001</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label for="field-2" class="control-label">Which Golf Club are they a member of?</label>
                                                    <select class="form-control" id="field-2">
                                                        <option>Aberdare Golf Club</option>
                                                        <option>Aberdovey Golf Club</option>
                                                        <option>Abergele Golf Club</option>
                                                        <option>Abersoch Golf Club</option>
                                                        <option>Aberystwyth Golf Club</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="field-3" class="control-label">Member of a second Golf Club?</label>
                                                    <select class="form-control" id="field-3">
                                                        <option>No</option>
                                                        <option>Yes</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="field-4" class="control-label">Select Golf Club</label>
                                                    <select class="form-control" id="field-4">
                                                        <option>Select</option>
                                                        <option>Aberdare Golf Club</option>
                                                        <option>Aberdovey Golf Club</option>
                                                        <option>Abergele Golf Club</option>
                                                        <option>Abersoch Golf Club</option>
                                                        <option>Aberystwyth Golf Club</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label for="field-5" class="control-label">Golfer Card Membership Category</label>
                                                    <select class="form-control" id="field-5">
                                                        <option>Level 1</option>
                                                        <option>Level 2</option>
                                                        <option>Level 3</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="field-6" class="control-label">Title</label>
                                                    <input type="text" class="form-control" id="field-6">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="field-7" class="control-label">First Name</label>
                                                    <input type="text" class="form-control" id="field-7">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="field-8" class="control-label">Last Name</label>
                                                    <input type="text" class="form-control" id="field-8">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="field-9" class="control-label">Gender</label>
                                                    <select class="form-control" id="field-9">
                                                        <option>Female</option>
                                                        <option>Male</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="field-10" class="control-label">Date of Birth</label>
                                                    <!-- Select Date -->
                                                    <div>
                                                        <div class="input-group">
                                                            <input type="text" class="form-control" placeholder="mm/dd/yyyy" id="datepicker">
                                                            <span class="input-group-addon bg-custom b-0"><i class="mdi mdi-calendar text-white"></i></span>
                                                        </div>
                                                    </div>
                                                    <!-- Select Date End -->
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label for="field-11" class="control-label">Email</label>
                                                    <input type="text" class="form-control" id="field-11">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label for="field-12" class="control-label">Contact Number</label>
                                                    <input type="text" class="form-control" id="field-12">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label for="field-13" class="control-label">Address Line 1</label>
                                                    <input type="text" class="form-control" id="field-13">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label for="field-14" class="control-label">Address Line 2</label>
                                                    <input type="text" class="form-control" id="field-14">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="field-15" class="control-label">Country</label>
                                                    <select class="form-control" id="field-15">
                                                        <option>England</option>
                                                        <option>Ireland</option>
                                                        <option>Northern Ireland</option>
                                                        <option>Scotland</option>
                                                        <option>Wales</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="field-16" class="control-label">County</label>
                                                    <select class="form-control" id="field-16">
                                                        <option>Bedfordshire</option>
                                                        <option>Berkshire</option>
                                                        <option>Bristol</option>
                                                        <option>Buckinghamshire</option>
                                                        <option>Cambridgeshire</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="field-17" class="control-label">Town</label>
                                                    <input type="text" class="form-control" id="field-17">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="field-18" class="control-label">Postcode</label>
                                                    <input type="text" class="form-control" id="field-18">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-12">
                                                <div class="checkbox checkbox-success">
                                                    <input id="confirm-marketing" type="checkbox" checked="">
                                                    <label for="confirm-marketing">
                                                        They would like to receive <a href="#" class="text-danger">Relevant Information</a>.
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-12">
                                                <div class="checkbox checkbox-success">
                                                    <input id="confirm" type="checkbox" checked="">
                                                    <label for="confirm">
                                                        They have read and agree to the <a href="#" class="text-danger">Terms and Conditions</a>.
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group no-margin">
                                                    <label for="field-19" class="control-label">Note</label>
                                                    <textarea class="form-control" id="field-19" placeholder="Include any additional notes for this Golfer."></textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary waves-effect" data-dismiss="modal">Close</button>
                                        <button type="button" class="btn btn-danger waves-effect waves-light">Save changes</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Add Golfer Modal End -->
                        <div id="bg-default" class="panel-collapse collapse in show">
                            <div class="portlet-body">
                                <div class="table-responsive">
                                    <table id="datatable-buttons" class="table table-striped table-bordered" cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>First Name</th>
                                                <th>Last Name</th>
                                                <th>Primary Membership Golf Club</th>
                                                <th>Gender</th>
                                                <th>Card Number</th>
                                                <th></th>
                                            </tr>
                                        </thead>


                                        <tbody>
                                            <tr>
                                                <td>10001</td>
                                                <td><a href="golfer.php" class="text-danger">Benjamin</a></td>
                                                <td><a href="golfer.php" class="text-danger">Chan</a></td>
                                                <td>Radyr Golf Club</td>
                                                <td>Male</td>
                                                <td>GCR210010</td>
                                                <td>
                                                    <div class="button-list pull-right">
                                                        <button type="button" class="btn btn-icon waves-effect btn-danger"><a href="golfer.php" class="text-white"><i class="fa fa-search"></i> </a></button>
                                                        <button type="button" class="btn btn-icon waves-effect waves-light btn-warning" id="sa-warning"> <i class="fa fa-remove"></i> </button>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>10002</td>
                                                <td><a href="golfer.php" class="text-danger">Andrew</a></td>
                                                <td><a href="golfer.php" class="text-danger">Watkins</a></td>
                                                <td>Radyr Golf Club</td>
                                                <td>Male</td>
                                                <td>GCR210012</td>
                                                <td>
                                                    <div class="button-list pull-right">
                                                        <button type="button" class="btn btn-icon waves-effect btn-danger"><a href="golfer.php" class="text-white"><i class="fa fa-search"></i> </a></button>
                                                        <button type="button" class="btn btn-icon waves-effect waves-light btn-warning" id="sa-warning"> <i class="fa fa-remove"></i> </button>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>10003</td>
                                                <td><a href="golfer.php" class="text-danger">Sarah</a></td>
                                                <td><a href="golfer.php" class="text-danger">Munrow</a></td>
                                                <td>Radyr Golf Club</td>
                                                <td>Female</td>
                                                <td>GCR210013</td>
                                                <td>
                                                    <div class="button-list pull-right">
                                                        <button type="button" class="btn btn-icon waves-effect btn-danger"><a href="golfer.php" class="text-white"><i class="fa fa-search"></i> </a></button>
                                                        <button type="button" class="btn btn-icon waves-effect waves-light btn-warning" id="sa-warning"> <i class="fa fa-remove"></i> </button>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>10004</td>
                                                <td><a href="golfer.php" class="text-danger">Paul</a></td>
                                                <td><a href="golfer.php" class="text-danger">Robinson</a></td>
                                                <td>Langland Bay Golf Club</td>
                                                <td>Male</td>
                                                <td>GCR210014</td>
                                                <td>
                                                    <div class="button-list pull-right">
                                                        <button type="button" class="btn btn-icon waves-effect btn-danger"><a href="golfer.php" class="text-white"><i class="fa fa-search"></i> </a></button>
                                                        <button type="button" class="btn btn-icon waves-effect waves-light btn-warning" id="sa-warning"> <i class="fa fa-remove"></i> </button>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>10005</td>
                                                <td><a href="golfer.php" class="text-danger">Katie</a></td>
                                                <td><a href="golfer.php" class="text-danger">White</a></td>
                                                <td>Langland Bay Golf Club</td>
                                                <td>Female</td>
                                                <td>GCR210015</td>
                                                <td>
                                                    <div class="button-list pull-right">
                                                        <button type="button" class="btn btn-icon waves-effect btn-danger"><a href="golfer.php" class="text-white"><i class="fa fa-search"></i> </a></button>
                                                        <button type="button" class="btn btn-icon waves-effect waves-light btn-warning" id="sa-warning"> <i class="fa fa-remove"></i> </button>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>10006</td>
                                                <td><a href="golfer.php" class="text-danger">Lee</a></td>
                                                <td><a href="golfer.php" class="text-danger">Dawkins</a></td>
                                                <td>Radyr Golf Club</td>
                                                <td>Male</td>
                                                <td>GCR210016</td>
                                                <td>
                                                    <div class="button-list pull-right">
                                                        <button type="button" class="btn btn-icon waves-effect btn-danger"><a href="golfer.php" class="text-white"><i class="fa fa-search"></i> </a></button>
                                                        <button type="button" class="btn btn-icon waves-effect waves-light btn-warning" id="sa-warning"> <i class="fa fa-remove"></i> </button>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>10007</td>
                                                <td><a href="golfer.php" class="text-danger">Jerry</a></td>
                                                <td><a href="golfer.php" class="text-danger">Peters</a></td>
                                                <td>Radyr Golf Club</td>
                                                <td>Male</td>
                                                <td>GCR210017</td>
                                                <td>
                                                    <div class="button-list pull-right">
                                                        <button type="button" class="btn btn-icon waves-effect btn-danger"><a href="golfer.php" class="text-white"><i class="fa fa-search"></i> </a></button>
                                                        <button type="button" class="btn btn-icon waves-effect waves-light btn-warning" id="sa-warning"> <i class="fa fa-remove"></i> </button>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>10008</td>
                                                <td><a href="golfer.php" class="text-danger">Claire</a></td>
                                                <td><a href="golfer.php" class="text-danger">Rogers</a></td>
                                                <td>Radyr Golf Club</td>
                                                <td>Female</td>
                                                <td>GCR210018</td>
                                                <td>
                                                    <div class="button-list pull-right">
                                                        <button type="button" class="btn btn-icon waves-effect btn-danger"><a href="golfer.php" class="text-white"><i class="fa fa-search"></i> </a></button>
                                                        <button type="button" class="btn btn-icon waves-effect waves-light btn-warning" id="sa-warning"> <i class="fa fa-remove"></i> </button>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>10009</td>
                                                <td><a href="golfer.php" class="text-danger">Terry</a></td>
                                                <td><a href="golfer.php" class="text-danger">Watkins</a></td>
                                                <td>Langland Bay Golf Club</td>
                                                <td>Male</td>
                                                <td>GCR210019</td>
                                                <td>
                                                    <div class="button-list pull-right">
                                                        <button type="button" class="btn btn-icon waves-effect btn-danger"><a href="golfer.php" class="text-white"><i class="fa fa-search"></i> </a></button>
                                                        <button type="button" class="btn btn-icon waves-effect waves-light btn-warning" id="sa-warning"> <i class="fa fa-remove"></i> </button>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>10010</td>
                                                <td><a href="golfer.php" class="text-danger">Jessica</a></td>
                                                <td><a href="golfer.php" class="text-danger">Beale</a></td>
                                                <td>Langland Bay Golf Club</td>
                                                <td>Female</td>
                                                <td>GCR210020</td>
                                                <td>
                                                    <div class="button-list pull-right">
                                                        <button type="button" class="btn btn-icon waves-effect btn-danger"><a href="golfer.php" class="text-white"><i class="fa fa-search"></i> </a></button>
                                                        <button type="button" class="btn btn-icon waves-effect waves-light btn-warning" id="sa-warning"> <i class="fa fa-remove"></i> </button>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>10011</td>
                                                <td><a href="golfer.php" class="text-danger">Neville</a></td>
                                                <td><a href="golfer.php" class="text-danger">Sanderson</a></td>
                                                <td>Radyr Golf Club</td>
                                                <td>Male</td>
                                                <td>GCR210021</td>
                                                <td>
                                                    <div class="button-list pull-right">
                                                        <button type="button" class="btn btn-icon waves-effect btn-danger"><a href="golfer.php" class="text-white"><i class="fa fa-search"></i> </a></button>
                                                        <button type="button" class="btn btn-icon waves-effect waves-light btn-warning" id="sa-warning"> <i class="fa fa-remove"></i> </button>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <!-- Player Activity Table Row End -->
                    </div>
                </div>
            </div>
            <!-- container end -->
        </div>
        <!-- content end -->
    </div>
</div>
