<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Player */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="player-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'FirstClubID')->textInput() ?>

    <?= $form->field($model, 'FirstName')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'LastName')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'DateOfBirth')->textInput() ?>

    <?= $form->field($model, 'Email')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'Address')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'RegisterationKey')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'Password')->passwordInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'isRegistered')->textInput() ?>

    <?= $form->field($model, 'PhoneNo')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'Title')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'IsMemberOfAnotherClub')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'OtherClubName')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'Gender')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'Address2')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'Town')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'County')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'Country')->textInput() ?>

    <?= $form->field($model, 'CountyCardId')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'CountyCardNumber')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'PostCode')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'Notes')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'player_lifetime_id')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'optIn')->textInput() ?>

    <?= $form->field($model, 'activation_key')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'on_date')->textInput() ?>

    <?= $form->field($model, 'OpgRegType')->textInput(['maxlength' => true]) ?>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
